"""Career Copilot AI Backend Application."""

__version__ = "1.0.0"
__author__ = "Career Copilot Team"
