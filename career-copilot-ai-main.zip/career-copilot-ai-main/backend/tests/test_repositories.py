"""Test user repository."""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.user import UserRepository
from app.database.models import User
from app.core.exceptions import DuplicateResourceException


@pytest.mark.asyncio
async def test_create_user(db_session: AsyncSession):
    """Test user creation."""
    repo = UserRepository(db_session)
    
    user = await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": "hashed_password",
    })
    
    assert user.email == "test@example.com"
    assert user.username == "testuser"


@pytest.mark.asyncio
async def test_get_user_by_id(db_session: AsyncSession):
    """Test getting user by ID."""
    repo = UserRepository(db_session)
    
    user = await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": "hashed_password",
    })
    
    fetched_user = await repo.get_by_id(user.id)
    
    assert fetched_user is not None
    assert fetched_user.email == "test@example.com"


@pytest.mark.asyncio
async def test_get_user_by_email(db_session: AsyncSession):
    """Test getting user by email."""
    repo = UserRepository(db_session)
    
    await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": "hashed_password",
    })
    
    user = await repo.get_by_email("test@example.com")
    
    assert user is not None
    assert user.username == "testuser"


@pytest.mark.asyncio
async def test_update_user(db_session: AsyncSession):
    """Test user update."""
    repo = UserRepository(db_session)
    
    user = await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": "hashed_password",
    })
    
    updated_user = await repo.update(user.id, {"full_name": "Updated Name"})
    
    assert updated_user.full_name == "Updated Name"
