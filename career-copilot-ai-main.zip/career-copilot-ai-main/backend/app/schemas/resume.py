"""Pydantic schemas for resumes."""

from datetime import datetime
from pydantic import BaseModel, Field
from app.database.models import ResumeStatus


class ResumeBase(BaseModel):
    """Base resume schema."""
    title: str | None = Field(None, max_length=255)


class ResumeCreate(ResumeBase):
    """Resume creation schema."""
    pass


class ResumeResponse(ResumeBase):
    """Resume response schema."""
    id: str
    user_id: str
    filename: str
    file_size: int
    file_type: str
    status: ResumeStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ResumeDetailResponse(ResumeResponse):
    """Resume detail response with parsed content."""
    raw_text: str | None = None
    contact_info: str | None = None
    summary: str | None = None
    experience: str | None = None
    education: str | None = None
    skills: str | None = None
    certifications: str | None = None


class ResumeAnalysisBase(BaseModel):
    """Base resume analysis schema."""
    ats_score: int = Field(..., ge=0, le=100)
    overall_rating: int = Field(..., ge=0, le=100)
    career_level: str = Field(..., max_length=50)
    estimated_salary_min: int | None = None
    estimated_salary_max: int | None = None


class ResumeAnalysisCreate(ResumeAnalysisBase):
    """Resume analysis creation schema."""
    grammar_mistakes: str | None = None
    formatting_issues: str | None = None
    hard_skills: str | None = None
    soft_skills: str | None = None
    missing_keywords: str | None = None
    weak_bullet_points: str | None = None
    suggestions: str | None = None


class ResumeAnalysisResponse(ResumeAnalysisCreate):
    """Resume analysis response schema."""
    id: str
    resume_id: str
    user_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
