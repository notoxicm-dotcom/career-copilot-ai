"""Vacancy API routes."""

from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession
import json

from app.core.dependencies import get_db
from app.auth.current_user import CurrentUserDependency
from app.database.models import Vacancy, ResumeJobComparison
from app.repositories.vacancy import VacancyRepository, ResumeJobComparisonRepository
from app.repositories.resume import ResumeRepository
from app.services.llm_factory import LLMFactory
from app.schemas.vacancy import VacancyCreate, VacancyResponse, ResumeJobComparisonResponse
from app.core.exceptions import ApplicationException

router = APIRouter(prefix="/vacancies", tags=["vacancies"])


@router.post("/", response_model=VacancyResponse, status_code=status.HTTP_201_CREATED)
async def create_vacancy(
    vacancy_data: VacancyCreate,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> VacancyResponse:
    """Create new job vacancy."""
    try:
        vacancy_repo = VacancyRepository(db)
        
        # Analyze vacancy with LLM
        llm = LLMFactory.get_provider()
        analysis = await llm.analyze_vacancy(vacancy_data.description)
        
        vacancy = await vacancy_repo.create({
            "user_id": current_user.id,
            "title": vacancy_data.title,
            "company": vacancy_data.company,
            "description": vacancy_data.description,
            "required_skills": json.dumps(analysis.get("analysis", {})),
        })
        
        await db.commit()
        return VacancyResponse.model_validate(vacancy)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to create vacancy")


@router.get("/{vacancy_id}", response_model=VacancyResponse)
async def get_vacancy(
    vacancy_id: str,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> VacancyResponse:
    """Get vacancy details."""
    try:
        vacancy_repo = VacancyRepository(db)
        vacancy = await vacancy_repo.get_by_id(vacancy_id)
        
        if not vacancy or vacancy.user_id != current_user.id:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        return VacancyResponse.model_validate(vacancy)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch vacancy")


@router.post("/compare/{vacancy_id}/{resume_id}", response_model=ResumeJobComparisonResponse)
async def compare_resume_to_job(
    vacancy_id: str,
    resume_id: str,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> ResumeJobComparisonResponse:
    """Compare resume to job vacancy."""
    try:
        vacancy_repo = VacancyRepository(db)
        resume_repo = ResumeRepository(db)
        comparison_repo = ResumeJobComparisonRepository(db)
        
        # Verify ownership
        vacancy = await vacancy_repo.get_by_id(vacancy_id)
        if not vacancy or vacancy.user_id != current_user.id:
            raise HTTPException(status_code=404, detail="Vacancy not found")
        
        resume = await resume_repo.get_by_id(resume_id)
        if not resume or resume.user_id != current_user.id:
            raise HTTPException(status_code=404, detail="Resume not found")
        
        # Check if comparison already exists
        existing = await comparison_repo.get_by_resume_and_vacancy(resume_id, vacancy_id)
        if existing:
            return ResumeJobComparisonResponse.model_validate(existing)
        
        # Compare with LLM
        llm = LLMFactory.get_provider()
        comparison_result = await llm.compare_resume_to_job(resume.raw_text or "", vacancy.description)
        
        comparison = await comparison_repo.create({
            "resume_id": resume_id,
            "vacancy_id": vacancy_id,
            "user_id": current_user.id,
            "match_score": 75,  # TODO: extract from LLM response
            "missing_skills": json.dumps(comparison_result),
        })
        
        await db.commit()
        return ResumeJobComparisonResponse.model_validate(comparison)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Comparison failed")
