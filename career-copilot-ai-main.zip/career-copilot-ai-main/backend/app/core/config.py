"""Application configuration settings."""

from typing import Literal

from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """Database configuration."""

    host: str = "localhost"
    port: int = 5432
    user: str = "postgres"
    password: str = "postgres"
    name: str = "career_copilot_dev"
    echo: bool = False
    pool_size: int = 20
    max_overflow: int = 40
    pool_timeout: int = 30
    pool_recycle: int = 3600

    @property
    def url(self) -> str:
        """Get database URL."""
        return (
            f"postgresql+asyncpg://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.name}"
        )

    class Config:
        env_prefix = "DATABASE_"
        case_sensitive = False


class RedisSettings(BaseSettings):
    """Redis configuration."""

    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: str | None = None
    encoding: str = "utf-8"
    decode_responses: bool = True

    @property
    def url(self) -> str:
        """Get Redis URL."""
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}/{self.db}"
        return f"redis://{self.host}:{self.port}/{self.db}"

    class Config:
        env_prefix = "REDIS_"
        case_sensitive = False


class JWTSettings(BaseSettings):
    """JWT authentication settings."""

    secret_key: str = "your-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    class Config:
        env_prefix = "JWT_"
        case_sensitive = False


class LLMSettings(BaseSettings):
    """LLM provider settings."""

    provider: Literal["openai", "claude", "gemini"] = "openai"
    openai_api_key: str | None = None
    anthropic_api_key: str | None = None
    google_api_key: str | None = None
    default_model: str = "gpt-4-turbo"
    temperature: float = 0.7
    max_tokens: int = 2048

    class Config:
        env_prefix = "LLM_"
        case_sensitive = False


class FileSettings(BaseSettings):
    """File upload settings."""

    max_upload_size: int = 10 * 1024 * 1024  # 10MB
    allowed_extensions: list[str] = ["pdf", "docx", "txt"]
    upload_dir: str = "./uploads"

    class Config:
        env_prefix = "FILE_"
        case_sensitive = False


class Settings(BaseSettings):
    """Main application settings."""

    app_name: str = "Career Copilot AI"
    app_version: str = "1.0.0"
    environment: Literal["development", "staging", "production"] = "development"
    debug: bool = True
    log_level: str = "INFO"
    
    # CORS
    cors_origins: list[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
    ]
    cors_allow_credentials: bool = True
    cors_allow_methods: list[str] = ["*"]
    cors_allow_headers: list[str] = ["*"]
    
    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_requests: int = 100
    rate_limit_period: int = 60  # seconds
    
    # Subconfigs
    database: DatabaseSettings = DatabaseSettings()
    redis: RedisSettings = RedisSettings()
    jwt: JWTSettings = JWTSettings()
    llm: LLMSettings = LLMSettings()
    files: FileSettings = FileSettings()

    class Config:
        env_file = ".env"
        case_sensitive = False
        env_nested_delimiter = "__"


def get_settings() -> Settings:
    """Get application settings singleton."""
    return Settings()


settings = get_settings()
