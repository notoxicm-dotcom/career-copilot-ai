"""Authentication API routes."""

from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.auth.service import AuthService
from app.auth.current_user import CurrentUserDependency
from app.schemas.auth import (
    TokenRequest,
    TokenResponse,
    RefreshTokenRequest,
    PasswordChangeRequest,
)
from app.schemas.user import UserCreate, UserResponse
from app.core.exceptions import ApplicationException

router = APIRouter(prefix="/auth", tags=["authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(user_data: UserCreate, db: AsyncSession = Depends(get_db)) -> UserResponse:
    """Register new user."""
    try:
        auth_service = AuthService(db)
        user = await auth_service.register(
            email=user_data.email,
            username=user_data.username,
            password=user_data.password,
            full_name=user_data.full_name,
        )
        return UserResponse.model_validate(user)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Registration failed")


@router.post("/login", response_model=TokenResponse)
async def login(credentials: TokenRequest, db: AsyncSession = Depends(get_db)) -> TokenResponse:
    """Login and get tokens."""
    try:
        auth_service = AuthService(db)
        user = await auth_service.authenticate(email=credentials.email, password=credentials.password)
        tokens = await auth_service.create_tokens(user)
        return tokens
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Login failed")


@router.post("/refresh", response_model=TokenResponse)
async def refresh(request: RefreshTokenRequest, db: AsyncSession = Depends(get_db)) -> TokenResponse:
    """Refresh access token."""
    try:
        auth_service = AuthService(db)
        tokens = await auth_service.refresh_access_token(request.refresh_token)
        return tokens
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Token refresh failed")


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(
    request: PasswordChangeRequest,
    current_user: CurrentUserDependency,
    db: AsyncSession = Depends(get_db),
) -> None:
    """Change user password."""
    try:
        auth_service = AuthService(db)
        await auth_service.change_password(
            current_user,
            request.old_password,
            request.new_password,
        )
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Password change failed")
