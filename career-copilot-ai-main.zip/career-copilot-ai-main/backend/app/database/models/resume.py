"""Resume database models."""

from datetime import datetime
from uuid import uuid4
from enum import Enum

from sqlalchemy import DateTime, String, Text, ForeignKey, Index, Enum as SQLEnum, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class ResumeStatus(str, Enum):
    """Resume processing status."""
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    PARSED = "parsed"
    ANALYZED = "analyzed"
    FAILED = "failed"


class Resume(Base):
    """Resume model."""

    __tablename__ = "resumes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # File information
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    file_path: Mapped[str] = mapped_column(String(500), nullable=False)
    file_size: Mapped[int] = mapped_column(Integer, nullable=False)
    file_type: Mapped[str] = mapped_column(String(10), nullable=False)  # pdf, docx, txt
    
    # Resume metadata
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    raw_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[ResumeStatus] = mapped_column(SQLEnum(ResumeStatus), default=ResumeStatus.UPLOADED, nullable=False, index=True)
    
    # Parsed sections
    contact_info: Mapped[str | None] = mapped_column(Text, nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    experience: Mapped[str | None] = mapped_column(Text, nullable=True)
    education: Mapped[str | None] = mapped_column(Text, nullable=True)
    skills: Mapped[str | None] = mapped_column(Text, nullable=True)
    certifications: Mapped[str | None] = mapped_column(Text, nullable=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_resume_user_created", "user_id", "created_at"),
        Index("idx_resume_status", "status"),
    )

    def __repr__(self) -> str:
        return f"<Resume(id={self.id}, user_id={self.user_id}, filename={self.filename})>"


class ResumeAnalysis(Base):
    """Resume analysis results."""

    __tablename__ = "resume_analyses"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    resume_id: Mapped[str] = mapped_column(String(36), ForeignKey("resumes.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Analysis metrics
    ats_score: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-100
    overall_rating: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-100
    career_level: Mapped[str] = mapped_column(String(50), nullable=False)
    estimated_salary_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    estimated_salary_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    
    # Analysis details (JSON stored as text)
    grammar_mistakes: Mapped[str | None] = mapped_column(Text, nullable=True)
    formatting_issues: Mapped[str | None] = mapped_column(Text, nullable=True)
    hard_skills: Mapped[str | None] = mapped_column(Text, nullable=True)
    soft_skills: Mapped[str | None] = mapped_column(Text, nullable=True)
    missing_keywords: Mapped[str | None] = mapped_column(Text, nullable=True)
    weak_bullet_points: Mapped[str | None] = mapped_column(Text, nullable=True)
    suggestions: Mapped[str | None] = mapped_column(Text, nullable=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_analysis_resume_created", "resume_id", "created_at"),
        Index("idx_analysis_user_created", "user_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<ResumeAnalysis(id={self.id}, resume_id={self.resume_id}, ats_score={self.ats_score})>"
