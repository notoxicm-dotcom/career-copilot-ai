"""Pydantic schemas for vacancies and job matching."""

from datetime import datetime
from pydantic import BaseModel, Field


class VacancyBase(BaseModel):
    """Base vacancy schema."""
    title: str = Field(..., max_length=255)
    company: str = Field(..., max_length=255)
    description: str


class VacancyCreate(VacancyBase):
    """Vacancy creation schema."""
    pass


class VacancyResponse(VacancyBase):
    """Vacancy response schema."""
    id: str
    user_id: str
    required_skills: str | None = None
    nice_to_have_skills: str | None = None
    seniority: str | None = None
    keywords: str | None = None
    technologies: str | None = None
    salary_min: int | None = None
    salary_max: int | None = None
    salary_currency: str | None = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ResumeJobComparisonBase(BaseModel):
    """Base resume job comparison schema."""
    match_score: int = Field(..., ge=0, le=100)


class ResumeJobComparisonCreate(ResumeJobComparisonBase):
    """Resume job comparison creation schema."""
    missing_skills: str | None = None
    matched_skills: str | None = None
    recommendations: str | None = None
    improvement_suggestions: str | None = None


class ResumeJobComparisonResponse(ResumeJobComparisonCreate):
    """Resume job comparison response schema."""
    id: str
    resume_id: str
    vacancy_id: str
    user_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
