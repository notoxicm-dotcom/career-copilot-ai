"""Resume service."""

from sqlalchemy.ext.asyncio import AsyncSession
from pathlib import Path

from app.database.models import Resume, ResumeStatus, ResumeAnalysis, User
from app.repositories.resume import ResumeRepository, ResumeAnalysisRepository
from app.services.resume_parsing import ResumeParsingService
from app.core.exceptions import ResourceNotFoundException, FileUploadException
from app.core.config import settings


class ResumeService:
    """Resume service for business logic."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.resume_repo = ResumeRepository(db)
        self.analysis_repo = ResumeAnalysisRepository(db)
        self.parsing_service = ResumeParsingService()

    async def create_resume(self, user: User, filename: str, file_path: str, file_size: int, file_type: str) -> Resume:
        """Create new resume record."""
        resume = await self.resume_repo.create({
            "user_id": user.id,
            "filename": filename,
            "file_path": file_path,
            "file_size": file_size,
            "file_type": file_type,
            "status": ResumeStatus.UPLOADED,
        })
        await self.db.commit()
        return resume

    async def get_resume(self, resume_id: str, user: User) -> Resume:
        """Get resume by ID."""
        resume = await self.resume_repo.get_by_id(resume_id)
        if not resume or resume.user_id != user.id:
            raise ResourceNotFoundException("Resume", resume_id)
        return resume

    async def get_user_resumes(self, user: User, limit: int = 10, offset: int = 0) -> list[Resume]:
        """Get user's resumes."""
        return await self.resume_repo.get_by_user_id(user.id, limit, offset)

    async def parse_resume(self, resume: Resume) -> Resume:
        """Parse resume and extract text and sections."""
        try:
            resume.status = ResumeStatus.PROCESSING
            await self.db.flush()
            
            # Extract text
            raw_text = self.parsing_service.extract_text(resume.file_path, resume.file_type)
            
            # Extract sections
            sections = self.parsing_service.extract_sections(raw_text)
            
            # Update resume
            resume.raw_text = raw_text
            resume.contact_info = sections.get("contact_info")
            resume.summary = sections.get("summary")
            resume.experience = sections.get("experience")
            resume.education = sections.get("education")
            resume.skills = ",".join(self.parsing_service.extract_skills(raw_text))
            resume.certifications = sections.get("certifications")
            resume.status = ResumeStatus.PARSED
            
            await self.db.commit()
            return resume
        except Exception as e:
            resume.status = ResumeStatus.FAILED
            await self.db.commit()
            raise FileUploadException(f"Resume parsing failed: {str(e)}")

    async def delete_resume(self, resume_id: str, user: User) -> None:
        """Delete resume."""
        resume = await self.get_resume(resume_id, user)
        
        # Delete physical file
        try:
            Path(resume.file_path).unlink(missing_ok=True)
        except Exception:
            pass
        
        await self.resume_repo.delete(resume_id)
        await self.db.commit()
