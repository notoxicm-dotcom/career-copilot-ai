"""Alembic configuration."""

from sqlalchemy import pool
from alembic import config as alembic_config


class Config(alembic_config.Config):
    """Alembic configuration."""

    def get_section(self, name: str, **kwargs):
        if config.config_ini_section != name and name in self.get_sections():
            return super().get_section_as_dict(name, **kwargs)
        return super().get_section(name, **kwargs)


config = Config("alembic.ini")
config.set_main_option("script_location", "alembic")
config.set_main_option("sqlalchemy.url", "")
