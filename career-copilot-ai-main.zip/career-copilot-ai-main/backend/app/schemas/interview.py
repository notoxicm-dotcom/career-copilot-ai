"""Pydantic schemas for interviews and AI requests."""

from datetime import datetime
from pydantic import BaseModel, Field
from app.database.models import InterviewType


class InterviewHistoryBase(BaseModel):
    """Base interview history schema."""
    interview_type: InterviewType
    title: str = Field(..., max_length=255)
    questions: str  # JSON array


class InterviewHistoryCreate(InterviewHistoryBase):
    """Interview history creation schema."""
    vacancy_id: str | None = None


class InterviewHistoryResponse(InterviewHistoryBase):
    """Interview history response schema."""
    id: str
    user_id: str
    vacancy_id: str | None = None
    user_answers: str | None = None
    ai_feedback: str | None = None
    score: int | None = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class InterviewAnswerSubmit(BaseModel):
    """Interview answer submission schema."""
    answers: list[str] = Field(..., min_items=1)


class AIRequestResponse(BaseModel):
    """AI request tracking response schema."""
    id: str
    user_id: str
    endpoint: str
    llm_provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_usd: float
    status: str
    error_message: str | None = None
    created_at: datetime

    class Config:
        from_attributes = True
