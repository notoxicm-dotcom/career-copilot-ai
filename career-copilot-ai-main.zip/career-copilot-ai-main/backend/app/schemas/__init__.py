"""Pydantic schemas package."""

from app.schemas.user import (
    UserBase,
    UserCreate,
    UserUpdate,
    UserResponse,
    UserDetailResponse,
)
from app.schemas.resume import (
    ResumeBase,
    ResumeCreate,
    ResumeResponse,
    ResumeDetailResponse,
    ResumeAnalysisBase,
    ResumeAnalysisCreate,
    ResumeAnalysisResponse,
)
from app.schemas.vacancy import (
    VacancyBase,
    VacancyCreate,
    VacancyResponse,
    ResumeJobComparisonBase,
    ResumeJobComparisonCreate,
    ResumeJobComparisonResponse,
)
from app.schemas.interview import (
    InterviewHistoryBase,
    InterviewHistoryCreate,
    InterviewHistoryResponse,
    InterviewAnswerSubmit,
    AIRequestResponse,
)
from app.schemas.auth import (
    TokenRequest,
    TokenResponse,
    RefreshTokenRequest,
    PasswordChangeRequest,
    PasswordResetRequest,
    PasswordResetConfirm,
)

__all__ = [
    "UserBase",
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "UserDetailResponse",
    "ResumeBase",
    "ResumeCreate",
    "ResumeResponse",
    "ResumeDetailResponse",
    "ResumeAnalysisBase",
    "ResumeAnalysisCreate",
    "ResumeAnalysisResponse",
    "VacancyBase",
    "VacancyCreate",
    "VacancyResponse",
    "ResumeJobComparisonBase",
    "ResumeJobComparisonCreate",
    "ResumeJobComparisonResponse",
    "InterviewHistoryBase",
    "InterviewHistoryCreate",
    "InterviewHistoryResponse",
    "InterviewAnswerSubmit",
    "AIRequestResponse",
    "TokenRequest",
    "TokenResponse",
    "RefreshTokenRequest",
    "PasswordChangeRequest",
    "PasswordResetRequest",
    "PasswordResetConfirm",
]
