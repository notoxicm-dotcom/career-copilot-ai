"""Vacancy and job matching database models."""

from datetime import datetime
from uuid import uuid4

from sqlalchemy import DateTime, String, Text, ForeignKey, Index, Integer
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class Vacancy(Base):
    """Job vacancy model."""

    __tablename__ = "vacancies"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Vacancy information
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    company: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    
    # Parsed data
    required_skills: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    nice_to_have_skills: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    seniority: Mapped[str | None] = mapped_column(String(50), nullable=True)
    keywords: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    technologies: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    
    # Salary information
    salary_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    salary_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    salary_currency: Mapped[str | None] = mapped_column(String(10), nullable=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_vacancy_user_created", "user_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<Vacancy(id={self.id}, title={self.title}, company={self.company})>"


class ResumeJobComparison(Base):
    """Resume to job comparison results."""

    __tablename__ = "resume_job_comparisons"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    resume_id: Mapped[str] = mapped_column(String(36), ForeignKey("resumes.id", ondelete="CASCADE"), nullable=False, index=True)
    vacancy_id: Mapped[str] = mapped_column(String(36), ForeignKey("vacancies.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Comparison results
    match_score: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-100
    missing_skills: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    matched_skills: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    recommendations: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    improvement_suggestions: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_comparison_resume_vacancy", "resume_id", "vacancy_id"),
        Index("idx_comparison_user_created", "user_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<ResumeJobComparison(id={self.id}, match_score={self.match_score})>"
