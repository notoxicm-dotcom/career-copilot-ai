"""Test authentication service."""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.service import AuthService
from app.auth.jwt import verify_password, hash_password
from app.database.models import User
from app.core.exceptions import AuthenticationException, ValidationException


@pytest.mark.asyncio
async def test_register_user(db_session: AsyncSession):
    """Test user registration."""
    auth_service = AuthService(db_session)
    
    user = await auth_service.register(
        email="test@example.com",
        username="testuser",
        password="password123",
        full_name="Test User",
    )
    
    assert user.email == "test@example.com"
    assert user.username == "testuser"
    assert user.full_name == "Test User"
    assert verify_password("password123", user.hashed_password)


@pytest.mark.asyncio
async def test_register_duplicate_email(db_session: AsyncSession):
    """Test registration with duplicate email."""
    auth_service = AuthService(db_session)
    
    await auth_service.register(
        email="test@example.com",
        username="testuser1",
        password="password123",
    )
    
    with pytest.raises(Exception):
        await auth_service.register(
            email="test@example.com",
            username="testuser2",
            password="password123",
        )


@pytest.mark.asyncio
async def test_authenticate_user(db_session: AsyncSession):
    """Test user authentication."""
    auth_service = AuthService(db_session)
    
    user = await auth_service.register(
        email="test@example.com",
        username="testuser",
        password="password123",
    )
    
    authenticated_user = await auth_service.authenticate(
        email="test@example.com",
        password="password123",
    )
    
    assert authenticated_user.id == user.id


@pytest.mark.asyncio
async def test_authenticate_wrong_password(db_session: AsyncSession):
    """Test authentication with wrong password."""
    auth_service = AuthService(db_session)
    
    await auth_service.register(
        email="test@example.com",
        username="testuser",
        password="password123",
    )
    
    with pytest.raises(AuthenticationException):
        await auth_service.authenticate(
            email="test@example.com",
            password="wrongpassword",
        )


@pytest.mark.asyncio
async def test_create_tokens(db_session: AsyncSession):
    """Test token creation."""
    auth_service = AuthService(db_session)
    
    user = await auth_service.register(
        email="test@example.com",
        username="testuser",
        password="password123",
    )
    
    tokens = await auth_service.create_tokens(user)
    
    assert tokens.access_token
    assert tokens.refresh_token
    assert tokens.token_type == "bearer"
