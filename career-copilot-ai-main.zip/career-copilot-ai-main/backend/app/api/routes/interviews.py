"""Interview API routes."""

from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession
import json

from app.core.dependencies import get_db
from app.auth.current_user import CurrentUserDependency
from app.database.models import InterviewHistory, InterviewType
from app.schemas.interview import InterviewHistoryCreate, InterviewHistoryResponse, InterviewAnswerSubmit
from app.services.llm_factory import LLMFactory
from app.core.exceptions import ApplicationException, ResourceNotFoundException
from sqlalchemy import select

router = APIRouter(prefix="/interviews", tags=["interviews"])


@router.post("/generate", response_model=InterviewHistoryResponse, status_code=status.HTTP_201_CREATED)
async def generate_interview(
    interview_data: InterviewHistoryCreate,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> InterviewHistoryResponse:
    """Generate interview questions."""
    try:
        # Get job description if vacancy_id provided
        job_description = ""
        if interview_data.vacancy_id:
            from app.repositories.vacancy import VacancyRepository
            vacancy_repo = VacancyRepository(db)
            vacancy = await vacancy_repo.get_by_id(interview_data.vacancy_id)
            if vacancy:
                job_description = vacancy.description
        
        # Generate questions with LLM
        llm = LLMFactory.get_provider()
        questions_response = await llm.generate_interview_questions(
            job_description,
            interview_data.interview_type.value,
        )
        
        interview = InterviewHistory(
            user_id=current_user.id,
            vacancy_id=interview_data.vacancy_id,
            interview_type=interview_data.interview_type,
            title=interview_data.title,
            questions=interview_data.questions or json.dumps(questions_response),
        )
        
        db.add(interview)
        await db.commit()
        await db.refresh(interview)
        
        return InterviewHistoryResponse.model_validate(interview)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to generate interview")


@router.get("/{interview_id}", response_model=InterviewHistoryResponse)
async def get_interview(
    interview_id: str,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> InterviewHistoryResponse:
    """Get interview details."""
    try:
        result = await db.execute(
            select(InterviewHistory).where(InterviewHistory.id == interview_id)
        )
        interview = result.scalar_one_or_none()
        
        if not interview or interview.user_id != current_user.id:
            raise ResourceNotFoundException("Interview", interview_id)
        
        return InterviewHistoryResponse.model_validate(interview)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch interview")


@router.post("/{interview_id}/submit-answers")
async def submit_answers(
    interview_id: str,
    answers: InterviewAnswerSubmit,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> InterviewHistoryResponse:
    """Submit interview answers."""
    try:
        result = await db.execute(
            select(InterviewHistory).where(InterviewHistory.id == interview_id)
        )
        interview = result.scalar_one_or_none()
        
        if not interview or interview.user_id != current_user.id:
            raise ResourceNotFoundException("Interview", interview_id)
        
        # Evaluate answers with LLM
        llm = LLMFactory.get_provider()
        questions = json.loads(interview.questions)
        
        total_score = 0
        feedback_list = []
        
        for i, (question, answer) in enumerate(zip(questions, answers.answers)):
            evaluation = await llm.evaluate_answer(question, answer)
            feedback_list.append(evaluation)
            # Extract score (assuming it's in the evaluation)
            total_score += 75  # TODO: extract from LLM response
        
        avg_score = total_score // len(answers.answers) if answers.answers else 0
        
        interview.user_answers = json.dumps(answers.answers)
        interview.ai_feedback = json.dumps(feedback_list)
        interview.score = avg_score
        
        await db.commit()
        await db.refresh(interview)
        
        return InterviewHistoryResponse.model_validate(interview)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to submit answers")
