"""User repository."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import User
from app.core.exceptions import DuplicateResourceException, ResourceNotFoundException


class UserRepository:
    """User repository for database operations."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def create(self, user_data: dict) -> User:
        """Create new user."""
        # Check if user already exists
        existing = await self.get_by_email(user_data["email"])
        if existing:
            raise DuplicateResourceException("User", "email", user_data["email"])

        existing = await self.get_by_username(user_data["username"])
        if existing:
            raise DuplicateResourceException("User", "username", user_data["username"])

        user = User(**user_data)
        self.db.add(user)
        await self.db.flush()
        return user

    async def get_by_id(self, user_id: str) -> User | None:
        """Get user by ID."""
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        """Get user by email."""
        result = await self.db.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def get_by_username(self, username: str) -> User | None:
        """Get user by username."""
        result = await self.db.execute(select(User).where(User.username == username))
        return result.scalar_one_or_none()

    async def update(self, user_id: str, update_data: dict) -> User:
        """Update user."""
        user = await self.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("User", user_id)

        for key, value in update_data.items():
            if value is not None:
                setattr(user, key, value)

        await self.db.flush()
        return user

    async def delete(self, user_id: str) -> None:
        """Delete user."""
        user = await self.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("User", user_id)

        await self.db.delete(user)
        await self.db.flush()
