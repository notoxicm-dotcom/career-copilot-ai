"""Resume parsing service."""

import os
import tempfile
from pathlib import Path
from typing import Any
import json

try:
    import PyPDF2
except ImportError:
    PyPDF2 = None

try:
    from docx import Document
except ImportError:
    Document = None

from app.core.exceptions import FileUploadException


class ResumeParsingService:
    """Service for parsing resume files."""

    ALLOWED_EXTENSIONS = ["pdf", "docx", "txt"]
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

    @staticmethod
    def extract_text_from_pdf(file_path: str) -> str:
        """Extract text from PDF file."""
        if not PyPDF2:
            raise FileUploadException("PDF parsing not available. Install PyPDF2.")
        
        try:
            text = ""
            with open(file_path, "rb") as pdf_file:
                pdf_reader = PyPDF2.PdfReader(pdf_file)
                for page in pdf_reader.pages:
                    text += page.extract_text()
            return text.strip()
        except Exception as e:
            raise FileUploadException(f"Failed to parse PDF: {str(e)}")

    @staticmethod
    def extract_text_from_docx(file_path: str) -> str:
        """Extract text from DOCX file."""
        if not Document:
            raise FileUploadException("DOCX parsing not available. Install python-docx.")
        
        try:
            doc = Document(file_path)
            text = "\n".join(paragraph.text for paragraph in doc.paragraphs)
            return text.strip()
        except Exception as e:
            raise FileUploadException(f"Failed to parse DOCX: {str(e)}")

    @staticmethod
    def extract_text_from_txt(file_path: str) -> str:
        """Extract text from TXT file."""
        try:
            with open(file_path, "r", encoding="utf-8") as txt_file:
                return txt_file.read().strip()
        except Exception as e:
            raise FileUploadException(f"Failed to parse TXT: {str(e)}")

    def extract_text(self, file_path: str, file_type: str) -> str:
        """Extract text from resume file based on type."""
        file_type = file_type.lower().strip(".")
        
        if file_type == "pdf":
            return self.extract_text_from_pdf(file_path)
        elif file_type == "docx":
            return self.extract_text_from_docx(file_path)
        elif file_type == "txt":
            return self.extract_text_from_txt(file_path)
        else:
            raise FileUploadException(f"Unsupported file type: {file_type}")

    @staticmethod
    def extract_sections(text: str) -> dict[str, str]:
        """Extract resume sections from raw text."""
        sections = {
            "contact_info": "",
            "summary": "",
            "experience": "",
            "education": "",
            "skills": "",
            "certifications": "",
        }
        
        # Common section keywords
        keywords = {
            "contact_info": ["contact", "email", "phone"],
            "summary": ["summary", "objective", "profile"],
            "experience": ["experience", "work", "employment"],
            "education": ["education", "degree", "university"],
            "skills": ["skills", "technical"],
            "certifications": ["certification", "license"],
        }
        
        lines = text.split("\n")
        current_section = None
        section_content = []
        
        for line in lines:
            line_lower = line.lower().strip()
            
            # Check if line is a section header
            found_section = False
            for section, keywords_list in keywords.items():
                if any(keyword in line_lower for keyword in keywords_list):
                    if current_section and section_content:
                        sections[current_section] = "\n".join(section_content).strip()
                    current_section = section
                    section_content = []
                    found_section = True
                    break
            
            if not found_section and current_section and line.strip():
                section_content.append(line)
        
        if current_section and section_content:
            sections[current_section] = "\n".join(section_content).strip()
        
        return sections

    @staticmethod
    def extract_skills(text: str) -> list[str]:
        """Extract skills from resume text."""
        # Common technical skills
        common_skills = [
            "python", "javascript", "java", "c++", "c#", "golang", "rust",
            "react", "vue", "angular", "fastapi", "django", "flask",
            "postgresql", "mongodb", "redis", "elasticsearch",
            "docker", "kubernetes", "aws", "gcp", "azure",
            "git", "jenkins", "ci/cd", "devops",
            "agile", "scrum", "sql", "rest api", "graphql",
        ]
        
        found_skills = []
        text_lower = text.lower()
        
        for skill in common_skills:
            if skill in text_lower:
                found_skills.append(skill)
        
        return list(set(found_skills))
