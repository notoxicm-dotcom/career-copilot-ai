"""Interview and AI request models."""

from datetime import datetime
from uuid import uuid4
from enum import Enum

from sqlalchemy import DateTime, String, Text, ForeignKey, Index, Enum as SQLEnum, Integer
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class InterviewType(str, Enum):
    """Interview question types."""
    TECHNICAL = "technical"
    BEHAVIORAL = "behavioral"
    HR = "hr"
    CODING = "coding"


class InterviewHistory(Base):
    """Interview preparation history."""

    __tablename__ = "interview_histories"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    vacancy_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("vacancies.id", ondelete="SET NULL"), nullable=True)
    
    # Interview details
    interview_type: Mapped[InterviewType] = mapped_column(SQLEnum(InterviewType), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    
    # Questions and answers
    questions: Mapped[str] = mapped_column(Text, nullable=False)  # JSON array
    user_answers: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON array
    ai_feedback: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    score: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 0-100
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_interview_user_created", "user_id", "created_at"),
        Index("idx_interview_type", "interview_type"),
    )

    def __repr__(self) -> str:
        return f"<InterviewHistory(id={self.id}, title={self.title}, type={self.interview_type})>"


class AIRequest(Base):
    """AI API request tracking."""

    __tablename__ = "ai_requests"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Request details
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False)
    llm_provider: Mapped[str] = mapped_column(String(50), nullable=False)
    model: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # Token usage
    prompt_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    completion_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    total_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    
    # Cost tracking
    cost_usd: Mapped[float] = mapped_column(nullable=False)
    
    # Status
    status: Mapped[str] = mapped_column(String(20), nullable=False)  # success, error
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("idx_ai_request_user_created", "user_id", "created_at"),
        Index("idx_ai_request_provider", "llm_provider"),
    )

    def __repr__(self) -> str:
        return f"<AIRequest(id={self.id}, provider={self.llm_provider}, tokens={self.total_tokens})>"
