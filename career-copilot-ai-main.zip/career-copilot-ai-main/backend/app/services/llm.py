"""LLM provider abstraction."""

from abc import ABC, abstractmethod
from typing import Any
from app.core.config import settings


class LLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def analyze_resume(self, resume_text: str) -> dict[str, Any]:
        """Analyze resume and return analysis results."""
        pass

    @abstractmethod
    async def analyze_vacancy(self, vacancy_text: str) -> dict[str, Any]:
        """Analyze vacancy and extract key information."""
        pass

    @abstractmethod
    async def compare_resume_to_job(self, resume_text: str, vacancy_text: str) -> dict[str, Any]:
        """Compare resume to job and return match analysis."""
        pass

    @abstractmethod
    async def generate_interview_questions(self, job_description: str, interview_type: str) -> list[str]:
        """Generate interview questions based on job description."""
        pass

    @abstractmethod
    async def evaluate_answer(self, question: str, answer: str) -> dict[str, Any]:
        """Evaluate interview answer."""
        pass

    @abstractmethod
    async def generate_cover_letter(self, resume_text: str, vacancy_text: str) -> str:
        """Generate cover letter."""
        pass

    @abstractmethod
    async def rewrite_resume(self, resume_text: str, improvements: list[str]) -> str:
        """Rewrite resume with improvements."""
        pass


class OpenAIProvider(LLMProvider):
    """OpenAI provider implementation."""

    def __init__(self) -> None:
        try:
            import openai
            self.client = openai.AsyncOpenAI(api_key=settings.llm.openai_api_key)
        except ImportError:
            raise ImportError("openai package not installed")

    async def analyze_resume(self, resume_text: str) -> dict[str, Any]:
        """Analyze resume using GPT-4."""
        prompt = f"""Analyze this resume and provide:
1. ATS Score (0-100)
2. Career Level
3. Grammar Mistakes
4. Formatting Issues
5. Hard Skills (list)
6. Soft Skills (list)
7. Missing Keywords
8. Weak Bullet Points
9. Suggestions for improvement
10. Estimated Salary Range
11. Overall Rating (0-100)

Resume:
{resume_text}

Provide response in JSON format."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return {"analysis": response.choices[0].message.content}

    async def analyze_vacancy(self, vacancy_text: str) -> dict[str, Any]:
        """Analyze job vacancy."""
        prompt = f"""Analyze this job description and extract:
1. Required Skills (list)
2. Nice-to-Have Skills (list)
3. Seniority Level
4. Technologies (list)
5. Keywords

Job Description:
{vacancy_text}

Provide response in JSON format."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return {"analysis": response.choices[0].message.content}

    async def compare_resume_to_job(self, resume_text: str, vacancy_text: str) -> dict[str, Any]:
        """Compare resume to job."""
        prompt = f"""Compare this resume to the job description and provide:
1. Match Score (0-100)
2. Matched Skills
3. Missing Skills
4. Recommendations
5. How to Improve Resume for this Job

Resume:
{resume_text}

Job Description:
{vacancy_text}

Provide response in JSON format."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return {"comparison": response.choices[0].message.content}

    async def generate_interview_questions(self, job_description: str, interview_type: str) -> list[str]:
        """Generate interview questions."""
        prompt = f"""Generate 5 {interview_type} interview questions for this job:

{job_description}

Return as JSON array of strings."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return {"questions": response.choices[0].message.content}

    async def evaluate_answer(self, question: str, answer: str) -> dict[str, Any]:
        """Evaluate interview answer."""
        prompt = f"""Evaluate this interview answer and provide:
1. Score (0-100)
2. Strengths
3. Weaknesses
4. Improvement Suggestions

Question: {question}
Answer: {answer}

Provide response in JSON format."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return {"evaluation": response.choices[0].message.content}

    async def generate_cover_letter(self, resume_text: str, vacancy_text: str) -> str:
        """Generate cover letter."""
        prompt = f"""Generate a professional cover letter based on:

Resume:
{resume_text}

Job Description:
{vacancy_text}"""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return response.choices[0].message.content

    async def rewrite_resume(self, resume_text: str, improvements: list[str]) -> str:
        """Rewrite resume with improvements."""
        improvements_str = "\n".join(f"- {imp}" for imp in improvements)
        prompt = f"""Rewrite this resume with these improvements:

{improvements_str}

Resume:
{resume_text}

Keep truthful information and improve bullet points."""

        response = await self.client.chat.completions.create(
            model=settings.llm.default_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=settings.llm.temperature,
            max_tokens=settings.llm.max_tokens,
        )
        
        return response.choices[0].message.content
