"""Test resume service."""

import pytest
from pathlib import Path
from sqlalchemy.ext.asyncio import AsyncSession

from app.services.resume import ResumeService
from app.services.resume_parsing import ResumeParsingService
from app.database.models import User, ResumeStatus
from app.repositories.user import UserRepository
from app.core.exceptions import ResourceNotFoundException


@pytest.fixture
async def test_user(db_session: AsyncSession) -> User:
    """Create test user."""
    repo = UserRepository(db_session)
    user = await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": "hashed_password",
    })
    await db_session.commit()
    return user


@pytest.mark.asyncio
async def test_create_resume(db_session: AsyncSession, test_user: User):
    """Test resume creation."""
    service = ResumeService(db_session)
    
    resume = await service.create_resume(
        user=test_user,
        filename="test.pdf",
        file_path="/path/to/test.pdf",
        file_size=1024,
        file_type="pdf",
    )
    
    assert resume.filename == "test.pdf"
    assert resume.user_id == test_user.id
    assert resume.status == ResumeStatus.UPLOADED


@pytest.mark.asyncio
async def test_get_user_resumes(db_session: AsyncSession, test_user: User):
    """Test getting user resumes."""
    service = ResumeService(db_session)
    
    await service.create_resume(
        user=test_user,
        filename="test1.pdf",
        file_path="/path/to/test1.pdf",
        file_size=1024,
        file_type="pdf",
    )
    
    await service.create_resume(
        user=test_user,
        filename="test2.pdf",
        file_path="/path/to/test2.pdf",
        file_size=1024,
        file_type="pdf",
    )
    
    resumes = await service.get_user_resumes(test_user)
    
    assert len(resumes) == 2


@pytest.mark.asyncio
async def test_extract_skills():
    """Test skill extraction."""
    parser = ResumeParsingService()
    
    resume_text = """
    Python Developer with 5 years of experience.
    Skills: Python, JavaScript, React, Django, FastAPI, PostgreSQL, Docker, Kubernetes
    """
    
    skills = parser.extract_skills(resume_text)
    
    assert "python" in skills
    assert "javascript" in skills
    assert "react" in skills
    assert "django" in skills
    assert "fastapi" in skills


@pytest.mark.asyncio
async def test_extract_sections():
    """Test section extraction."""
    parser = ResumeParsingService()
    
    resume_text = """
    CONTACT
    Email: test@example.com
    Phone: 123-456-7890
    
    SUMMARY
    Experienced software developer
    
    EXPERIENCE
    Senior Developer at Tech Co
    
    EDUCATION
    BS Computer Science
    """
    
    sections = parser.extract_sections(resume_text)
    
    assert "email" in sections["contact_info"].lower()
    assert "experienced" in sections["summary"].lower()
    assert "senior" in sections["experience"].lower()
    assert "computer science" in sections["education"].lower()
