"""Test API endpoints."""

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.main import app
from app.repositories.user import UserRepository
from app.auth.jwt import hash_password, create_access_token


@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    """Test health check endpoint."""
    response = await client.get("/health")
    
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_register_user(client: AsyncClient):
    """Test user registration endpoint."""
    response = await client.post(
        "/api/auth/register",
        json={
            "email": "newuser@example.com",
            "username": "newuser",
            "password": "password123",
            "full_name": "New User",
        },
    )
    
    assert response.status_code == 201
    data = response.json()
    assert data["email"] == "newuser@example.com"
    assert data["username"] == "newuser"


@pytest.mark.asyncio
async def test_login_user(client: AsyncClient, db_session: AsyncSession):
    """Test user login endpoint."""
    # Create user
    repo = UserRepository(db_session)
    await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": hash_password("password123"),
    })
    await db_session.commit()
    
    response = await client.post(
        "/api/auth/login",
        json={
            "email": "test@example.com",
            "password": "password123",
        },
    )
    
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "bearer"


@pytest.mark.asyncio
async def test_get_current_user(client: AsyncClient, db_session: AsyncSession):
    """Test get current user endpoint."""
    # Create user
    repo = UserRepository(db_session)
    user = await repo.create({
        "email": "test@example.com",
        "username": "testuser",
        "hashed_password": hash_password("password123"),
    })
    await db_session.commit()
    
    # Create token
    token = create_access_token({"sub": user.id})
    
    response = await client.get(
        "/api/users/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "test@example.com"
