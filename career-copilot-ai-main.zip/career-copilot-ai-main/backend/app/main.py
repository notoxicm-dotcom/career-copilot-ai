"""Main FastAPI application."""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.responses import ORJSONResponse

from app.core.config import settings
from app.core.logging import get_logger
from app.database import init_db, close_db
from app.api.middleware import setup_middleware, setup_exception_handlers
from app.api.routes import (
    auth_router,
    users_router,
    resumes_router,
    vacancies_router,
    interviews_router,
)

logger = get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application startup and shutdown."""
    # Startup
    logger.info(f"Starting {settings.app_name} v{settings.app_version}")
    logger.info(f"Environment: {settings.environment}")
    await init_db()
    logger.info("Database initialized")
    
    yield
    
    # Shutdown
    logger.info("Shutting down application")
    await close_db()
    logger.info("Database closed")


def create_app() -> FastAPI:
    """Create FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Production-ready AI-powered career assistance platform",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
        default_response_class=ORJSONResponse,
        lifespan=lifespan,
    )
    
    # Setup middleware
    setup_middleware(app)
    
    # Setup exception handlers
    setup_exception_handlers(app)
    
    # Include routers
    app.include_router(auth_router, prefix="/api")
    app.include_router(users_router, prefix="/api")
    app.include_router(resumes_router, prefix="/api")
    app.include_router(vacancies_router, prefix="/api")
    app.include_router(interviews_router, prefix="/api")
    
    # Health check
    @app.get("/health")
    async def health_check():
        return {"status": "ok", "version": settings.app_version}
    
    return app


app = create_app()
