"""User service."""

from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime

from app.database.models import User
from app.repositories.user import UserRepository
from app.core.exceptions import ResourceNotFoundException


class UserService:
    """User service for business logic."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.user_repo = UserRepository(db)

    async def get_user(self, user_id: str) -> User:
        """Get user by ID."""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("User", user_id)
        return user

    async def update_user(self, user_id: str, update_data: dict) -> User:
        """Update user profile."""
        user = await self.user_repo.update(user_id, update_data)
        await self.db.commit()
        return user

    async def update_last_login(self, user_id: str) -> None:
        """Update user last login timestamp."""
        await self.user_repo.update(user_id, {"last_login_at": datetime.utcnow()})
        await self.db.commit()
