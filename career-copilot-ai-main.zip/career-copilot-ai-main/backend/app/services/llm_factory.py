"""LLM factory to create provider instances."""

from app.core.config import settings
from app.services.llm import LLMProvider, OpenAIProvider
from app.core.exceptions import LLMException


class LLMFactory:
    """Factory for creating LLM provider instances."""

    @staticmethod
    def get_provider() -> LLMProvider:
        """Get LLM provider based on configuration."""
        if settings.llm.provider == "openai":
            if not settings.llm.openai_api_key:
                raise LLMException("OpenAI API key not configured", "openai")
            return OpenAIProvider()
        elif settings.llm.provider == "claude":
            raise LLMException("Claude provider not yet implemented", "claude")
        elif settings.llm.provider == "gemini":
            raise LLMException("Gemini provider not yet implemented", "gemini")
        else:
            raise LLMException(f"Unknown LLM provider: {settings.llm.provider}")
