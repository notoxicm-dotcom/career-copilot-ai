"""User API routes."""

from fastapi import APIRouter, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.services.user import UserService
from app.auth.current_user import CurrentUserDependency
from app.schemas.user import UserResponse, UserUpdate
from app.core.exceptions import ApplicationException

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(current_user: CurrentUserDependency) -> UserResponse:
    """Get current user information."""
    return UserResponse.model_validate(current_user)


@router.put("/me", response_model=UserResponse)
async def update_current_user(
    update_data: UserUpdate,
    current_user: CurrentUserDependency,
    db: AsyncSession = Depends(get_db),
) -> UserResponse:
    """Update current user information."""
    try:
        user_service = UserService(db)
        updated_user = await user_service.update_user(
            current_user.id,
            update_data.model_dump(exclude_unset=True),
        )
        return UserResponse.model_validate(updated_user)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Update failed")
