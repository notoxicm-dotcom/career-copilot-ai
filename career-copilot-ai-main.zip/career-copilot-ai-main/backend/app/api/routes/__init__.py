"""API routes package."""

from app.api.routes.auth import router as auth_router
from app.api.routes.users import router as users_router
from app.api.routes.resumes import router as resumes_router
from app.api.routes.vacancies import router as vacancies_router
from app.api.routes.interviews import router as interviews_router

__all__ = [
    "auth_router",
    "users_router",
    "resumes_router",
    "vacancies_router",
    "interviews_router",
]
