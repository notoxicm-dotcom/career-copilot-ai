"""Vacancy repository."""

from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Vacancy, ResumeJobComparison
from app.core.exceptions import ResourceNotFoundException


class VacancyRepository:
    """Vacancy repository for database operations."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def create(self, vacancy_data: dict) -> Vacancy:
        """Create new vacancy."""
        vacancy = Vacancy(**vacancy_data)
        self.db.add(vacancy)
        await self.db.flush()
        return vacancy

    async def get_by_id(self, vacancy_id: str) -> Vacancy | None:
        """Get vacancy by ID."""
        result = await self.db.execute(select(Vacancy).where(Vacancy.id == vacancy_id))
        return result.scalar_one_or_none()

    async def get_by_user_id(self, user_id: str, limit: int = 10, offset: int = 0) -> list[Vacancy]:
        """Get vacancies by user ID."""
        result = await self.db.execute(
            select(Vacancy)
            .where(Vacancy.user_id == user_id)
            .order_by(desc(Vacancy.created_at))
            .limit(limit)
            .offset(offset)
        )
        return result.scalars().all()

    async def update(self, vacancy_id: str, update_data: dict) -> Vacancy:
        """Update vacancy."""
        vacancy = await self.get_by_id(vacancy_id)
        if not vacancy:
            raise ResourceNotFoundException("Vacancy", vacancy_id)

        for key, value in update_data.items():
            if value is not None:
                setattr(vacancy, key, value)

        await self.db.flush()
        return vacancy

    async def delete(self, vacancy_id: str) -> None:
        """Delete vacancy."""
        vacancy = await self.get_by_id(vacancy_id)
        if not vacancy:
            raise ResourceNotFoundException("Vacancy", vacancy_id)

        await self.db.delete(vacancy)
        await self.db.flush()


class ResumeJobComparisonRepository:
    """Resume job comparison repository."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def create(self, comparison_data: dict) -> ResumeJobComparison:
        """Create new comparison."""
        comparison = ResumeJobComparison(**comparison_data)
        self.db.add(comparison)
        await self.db.flush()
        return comparison

    async def get_by_id(self, comparison_id: str) -> ResumeJobComparison | None:
        """Get comparison by ID."""
        result = await self.db.execute(select(ResumeJobComparison).where(ResumeJobComparison.id == comparison_id))
        return result.scalar_one_or_none()

    async def get_by_resume_and_vacancy(self, resume_id: str, vacancy_id: str) -> ResumeJobComparison | None:
        """Get comparison by resume and vacancy IDs."""
        result = await self.db.execute(
            select(ResumeJobComparison).where(
                (ResumeJobComparison.resume_id == resume_id) & (ResumeJobComparison.vacancy_id == vacancy_id)
            )
        )
        return result.scalar_one_or_none()
