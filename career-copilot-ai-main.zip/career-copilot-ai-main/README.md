# Career Copilot AI

🚀 Production-ready AI-powered career assistance platform built with FastAPI, React, and modern DevOps practices.

## ✨ Features

- 🤖 **AI-Powered Resume Analysis**: Intelligent resume parsing and scoring
- 💼 **Job Matching**: Compare your resume against job descriptions  
- 👨‍💼 **Interview Preparation**: Generate and practice interview questions
- 📊 **Career Insights**: Get personalized career recommendations
- 🔐 **Secure Authentication**: JWT-based authentication with refresh tokens
- 🎨 **Modern UI**: React-based responsive interface
- ⚡ **Scalable Backend**: FastAPI with async support
- 🐳 **Docker Ready**: Complete Docker and docker-compose setup

## 🛠 Tech Stack

### Backend
- **Framework**: FastAPI 0.104+
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Cache**: Redis
- **LLM**: OpenAI GPT-4, Claude, Google Gemini
- **Authentication**: JWT with bcrypt
- **Testing**: pytest with asyncio

### Frontend
- **Framework**: React 18+
- **Language**: TypeScript
- **State Management**: Redux Toolkit
- **UI Library**: Material-UI
- **API Client**: Axios

### DevOps
- **Containerization**: Docker & Docker Compose
- **Reverse Proxy**: Nginx
- **CI/CD**: GitHub Actions

## 📁 Project Structure

```
.
├── backend/
│   ├── app/
│   │   ├── api/routes/          # API endpoints
│   │   ├── auth/                # Authentication
│   │   ├── core/                # Core utilities
│   │   ├── database/            # Database models
│   │   ├── repositories/        # Data access layer
│   │   ├── schemas/             # Pydantic schemas
│   │   ├── services/            # Business logic
│   │   └── main.py              # FastAPI app
│   ├── tests/                   # Unit tests
│   ├── alembic/                 # Database migrations
│   ├── requirements.txt
│   └── Dockerfile
│
├── frontend/
│   ├── src/
│   ├── package.json
│   └── Dockerfile
│
├── docker-compose.yml
├── nginx.conf
└── README.md
```

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Python 3.11+ (for local development)
- Node.js 18+ (for frontend)

### Using Docker Compose

```bash
# Clone repository
git clone https://github.com/blonde1n/career-copilot-ai.git
cd career-copilot-ai

# Copy environment file
cp .env.example .env

# Start services
docker-compose up -d

# Access the application
# Frontend: http://localhost:3000
# Backend API: http://localhost:8000/api
# API Docs: http://localhost:8000/api/docs
```

### Local Development

#### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload
```

#### Frontend
```bash
cd frontend
npm install
npm start
```

## 📚 API Documentation

Full API documentation is available at `/api/docs`

### Authentication

```bash
# Register
POST /api/auth/register
{
  "email": "user@example.com",
  "username": "username",
  "password": "password123",
  "full_name": "Full Name"
}

# Login
POST /api/auth/login
{
  "email": "user@example.com",
  "password": "password123"
}
```

### Resume Management

```bash
# Upload resume
POST /api/resumes/upload
Content-Type: multipart/form-data
File: resume.pdf

# Get resumes
GET /api/resumes/

# Get resume details
GET /api/resumes/{resume_id}

# Delete resume
DELETE /api/resumes/{resume_id}
```

## 🧪 Testing

### Backend
```bash
cd backend
pytest
pytest --cov=app
```

### Frontend
```bash
cd frontend
npm test
npm test -- --coverage
```

## 🗄️ Database Migrations

```bash
cd backend

# Create migration
alembic revision --autogenerate -m "Add new column"

# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1
```

## 📋 Environment Variables

```bash
# .env
APP_NAME="Career Copilot AI"
ENVIRONMENT="development"

DATABASE_URL="postgresql+asyncpg://user:pass@localhost/db"
REDIS_URL="redis://localhost:6379/0"

JWT_SECRET_KEY="your-secret-key"
OPENAI_API_KEY="sk-..."

CORS_ORIGINS="http://localhost:3000,http://localhost"
```

## 🔒 Security Checklist

- [ ] Change JWT_SECRET_KEY in production
- [ ] Use strong database passwords
- [ ] Enable HTTPS with SSL certificates
- [ ] Setup environment-specific configs
- [ ] Configure rate limiting
- [ ] Setup error tracking (Sentry)

## 🚢 Deployment

### Production Build
```bash
docker build -f backend/Dockerfile -t careerchat-backend:latest .
docker build -f frontend/Dockerfile -t careerchat-frontend:latest .
```

### Using Docker Compose
```bash
docker-compose -f docker-compose.yml up -d
```

## 📈 Performance

- Async/await for I/O operations
- Database query optimization
- Redis caching
- Response compression
- CDN for static assets

## 🤝 Contributing

1. Create feature branch
2. Commit changes
3. Create pull request
4. Ensure tests pass

## 📄 License

MIT License - see LICENSE for details

## 📞 Support

For support, email support@careerchat.ai or open an issue on GitHub.

---

**Built with ❤️ by the Career Copilot AI team**
