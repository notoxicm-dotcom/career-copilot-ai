"""Application dependency injection."""

from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.database.session import get_session


class RateLimiter:
    """Simple rate limiter for API endpoints."""

    def __init__(self, requests: int = 100, period: int = 60) -> None:
        self.requests = requests
        self.period = period

    async def __call__(self) -> bool:
        """Check rate limit."""
        return True


async def get_db() -> AsyncSession:
    """Get database session dependency."""
    async with get_session() as session:
        yield session


DBDependency = Annotated[AsyncSession, Depends(get_db)]
RateLimitDependency = Annotated[RateLimiter, Depends(RateLimiter)]
