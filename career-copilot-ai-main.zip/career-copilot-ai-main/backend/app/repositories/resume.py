"""Resume repository."""

from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import Resume, ResumeStatus, ResumeAnalysis
from app.core.exceptions import ResourceNotFoundException


class ResumeRepository:
    """Resume repository for database operations."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def create(self, resume_data: dict) -> Resume:
        """Create new resume."""
        resume = Resume(**resume_data)
        self.db.add(resume)
        await self.db.flush()
        return resume

    async def get_by_id(self, resume_id: str) -> Resume | None:
        """Get resume by ID."""
        result = await self.db.execute(select(Resume).where(Resume.id == resume_id))
        return result.scalar_one_or_none()

    async def get_by_user_id(self, user_id: str, limit: int = 10, offset: int = 0) -> list[Resume]:
        """Get resumes by user ID."""
        result = await self.db.execute(
            select(Resume)
            .where(Resume.user_id == user_id)
            .order_by(desc(Resume.created_at))
            .limit(limit)
            .offset(offset)
        )
        return result.scalars().all()

    async def update(self, resume_id: str, update_data: dict) -> Resume:
        """Update resume."""
        resume = await self.get_by_id(resume_id)
        if not resume:
            raise ResourceNotFoundException("Resume", resume_id)

        for key, value in update_data.items():
            if value is not None:
                setattr(resume, key, value)

        await self.db.flush()
        return resume

    async def delete(self, resume_id: str) -> None:
        """Delete resume."""
        resume = await self.get_by_id(resume_id)
        if not resume:
            raise ResourceNotFoundException("Resume", resume_id)

        await self.db.delete(resume)
        await self.db.flush()


class ResumeAnalysisRepository:
    """Resume analysis repository for database operations."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def create(self, analysis_data: dict) -> ResumeAnalysis:
        """Create new resume analysis."""
        analysis = ResumeAnalysis(**analysis_data)
        self.db.add(analysis)
        await self.db.flush()
        return analysis

    async def get_by_id(self, analysis_id: str) -> ResumeAnalysis | None:
        """Get analysis by ID."""
        result = await self.db.execute(select(ResumeAnalysis).where(ResumeAnalysis.id == analysis_id))
        return result.scalar_one_or_none()

    async def get_by_resume_id(self, resume_id: str) -> ResumeAnalysis | None:
        """Get latest analysis by resume ID."""
        result = await self.db.execute(
            select(ResumeAnalysis)
            .where(ResumeAnalysis.resume_id == resume_id)
            .order_by(desc(ResumeAnalysis.created_at))
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_by_user_id(self, user_id: str, limit: int = 10, offset: int = 0) -> list[ResumeAnalysis]:
        """Get analyses by user ID."""
        result = await self.db.execute(
            select(ResumeAnalysis)
            .where(ResumeAnalysis.user_id == user_id)
            .order_by(desc(ResumeAnalysis.created_at))
            .limit(limit)
            .offset(offset)
        )
        return result.scalars().all()
