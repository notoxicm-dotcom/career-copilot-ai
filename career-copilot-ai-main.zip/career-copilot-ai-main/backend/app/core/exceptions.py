"""Application custom exceptions."""

from typing import Any


class ApplicationException(Exception):
    """Base application exception."""

    def __init__(
        self,
        message: str,
        error_code: str | None = None,
        status_code: int = 500,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)


class ValidationException(ApplicationException):
    """Validation error exception."""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            status_code=422,
            details=details,
        )


class AuthenticationException(ApplicationException):
    """Authentication error exception."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            status_code=401,
        )


class AuthorizationException(ApplicationException):
    """Authorization error exception."""

    def __init__(self, message: str = "Insufficient permissions") -> None:
        super().__init__(
            message=message,
            error_code="AUTHORIZATION_ERROR",
            status_code=403,
        )


class ResourceNotFoundException(ApplicationException):
    """Resource not found exception."""

    def __init__(self, resource: str, identifier: str | int) -> None:
        super().__init__(
            message=f"{resource} with id {identifier} not found",
            error_code="RESOURCE_NOT_FOUND",
            status_code=404,
        )


class DuplicateResourceException(ApplicationException):
    """Duplicate resource exception."""

    def __init__(self, resource: str, field: str, value: str) -> None:
        super().__init__(
            message=f"{resource} with {field} '{value}' already exists",
            error_code="DUPLICATE_RESOURCE",
            status_code=409,
        )


class FileUploadException(ApplicationException):
    """File upload error exception."""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            message=message,
            error_code="FILE_UPLOAD_ERROR",
            status_code=400,
            details=details,
        )


class LLMException(ApplicationException):
    """LLM provider error exception."""

    def __init__(self, message: str, provider: str | None = None) -> None:
        super().__init__(
            message=message,
            error_code="LLM_ERROR",
            status_code=503,
            details={"provider": provider} if provider else {},
        )


class DatabaseException(ApplicationException):
    """Database error exception."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            status_code=500,
        )
