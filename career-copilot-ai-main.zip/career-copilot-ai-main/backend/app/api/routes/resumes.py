"""Resume API routes."""

from fastapi import APIRouter, HTTPException, status, Depends, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from pathlib import Path
import aiofiles

from app.core.dependencies import get_db
from app.services.resume import ResumeService
from app.auth.current_user import CurrentUserDependency
from app.schemas.resume import ResumeResponse, ResumeDetailResponse, ResumeAnalysisResponse
from app.core.exceptions import ApplicationException, FileUploadException
from app.core.config import settings

router = APIRouter(prefix="/resumes", tags=["resumes"])


@router.post("/upload", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload_resume(
    file: UploadFile = File(...),
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> ResumeResponse:
    """Upload resume file."""
    try:
        # Validate file
        if not file.filename:
            raise FileUploadException("No filename provided")
        
        file_ext = Path(file.filename).suffix.lower().strip(".")
        if file_ext not in settings.files.allowed_extensions:
            raise FileUploadException(
                f"File type not allowed. Allowed types: {', '.join(settings.files.allowed_extensions)}"
            )
        
        # Read and check file size
        content = await file.read()
        if len(content) > settings.files.max_upload_size:
            raise FileUploadException(
                f"File size exceeds maximum allowed size of {settings.files.max_upload_size / 1024 / 1024}MB"
            )
        
        # Create uploads directory
        upload_dir = Path(settings.files.upload_dir)
        upload_dir.mkdir(exist_ok=True, parents=True)
        
        # Save file
        file_path = upload_dir / f"{current_user.id}_{file.filename}"
        async with aiofiles.open(file_path, "wb") as f:
            await f.write(content)
        
        # Create resume record
        resume_service = ResumeService(db)
        resume = await resume_service.create_resume(
            user=current_user,
            filename=file.filename,
            file_path=str(file_path),
            file_size=len(content),
            file_type=file_ext,
        )
        
        # Parse resume
        await resume_service.parse_resume(resume)
        
        return ResumeResponse.model_validate(resume)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Upload failed")


@router.get("/", response_model=list[ResumeResponse])
async def list_resumes(
    limit: int = 10,
    offset: int = 0,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> list[ResumeResponse]:
    """List user's resumes."""
    try:
        resume_service = ResumeService(db)
        resumes = await resume_service.get_user_resumes(current_user, limit, offset)
        return [ResumeResponse.model_validate(r) for r in resumes]
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch resumes")


@router.get("/{resume_id}", response_model=ResumeDetailResponse)
async def get_resume(
    resume_id: str,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> ResumeDetailResponse:
    """Get resume details."""
    try:
        resume_service = ResumeService(db)
        resume = await resume_service.get_resume(resume_id, current_user)
        return ResumeDetailResponse.model_validate(resume)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch resume")


@router.delete("/{resume_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_resume(
    resume_id: str,
    current_user: CurrentUserDependency = Depends(),
    db: AsyncSession = Depends(get_db),
) -> None:
    """Delete resume."""
    try:
        resume_service = ResumeService(db)
        await resume_service.delete_resume(resume_id, current_user)
    except ApplicationException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to delete resume")
