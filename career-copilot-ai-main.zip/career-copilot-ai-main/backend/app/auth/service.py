"""Authentication service."""

from datetime import timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.jwt import (
    create_access_token,
    create_refresh_token,
    verify_token,
    hash_password,
    verify_password,
)
from app.core.exceptions import AuthenticationException, ValidationException
from app.database.models import User
from app.repositories.user import UserRepository
from app.schemas.auth import TokenResponse
from app.core.config import settings


class AuthService:
    """Authentication service."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.user_repo = UserRepository(db)

    async def register(self, email: str, username: str, password: str, full_name: str | None = None) -> User:
        """Register new user."""
        if len(password) < 8:
            raise ValidationException("Password must be at least 8 characters long")
        
        hashed_password = hash_password(password)
        
        user = await self.user_repo.create({
            "email": email,
            "username": username,
            "full_name": full_name,
            "hashed_password": hashed_password,
        })
        
        await self.db.commit()
        return user

    async def authenticate(self, email: str, password: str) -> User:
        """Authenticate user with email and password."""
        user = await self.user_repo.get_by_email(email)
        
        if not user or not verify_password(password, user.hashed_password):
            raise AuthenticationException("Invalid email or password")
        
        if not user.is_active:
            raise AuthenticationException("User account is inactive")
        
        return user

    async def create_tokens(self, user: User) -> TokenResponse:
        """Create access and refresh tokens for user."""
        access_token = create_access_token(
            data={"sub": user.id},
            expires_delta=timedelta(minutes=settings.jwt.access_token_expire_minutes),
        )
        
        refresh_token = create_refresh_token(
            data={"sub": user.id},
            expires_delta=timedelta(days=settings.jwt.refresh_token_expire_days),
        )
        
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.jwt.access_token_expire_minutes * 60,
        )

    async def refresh_access_token(self, refresh_token: str) -> TokenResponse:
        """Refresh access token using refresh token."""
        try:
            payload = verify_token(refresh_token, token_type="refresh")
            user_id = payload.get("sub")
            
            if not user_id:
                raise AuthenticationException("Invalid refresh token")
            
            user = await self.user_repo.get_by_id(user_id)
            if not user or not user.is_active:
                raise AuthenticationException("User not found or inactive")
            
            return await self.create_tokens(user)
        except Exception as e:
            raise AuthenticationException(f"Token refresh failed: {str(e)}") from e

    async def change_password(self, user: User, old_password: str, new_password: str) -> None:
        """Change user password."""
        if not verify_password(old_password, user.hashed_password):
            raise AuthenticationException("Current password is incorrect")
        
        if len(new_password) < 8:
            raise ValidationException("Password must be at least 8 characters long")
        
        if old_password == new_password:
            raise ValidationException("New password must be different from current password")
        
        hashed_password = hash_password(new_password)
        await self.user_repo.update(user.id, {"hashed_password": hashed_password})
        await self.db.commit()
